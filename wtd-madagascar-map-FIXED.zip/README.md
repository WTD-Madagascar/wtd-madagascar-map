# WTD Madagascar — Cartographie territoriale

## Description
WTD Madagascar est une cartographie interactive des services essentiels,
des infrastructures locales et des usages réels du territoire.

Fonctionne avec Google Maps (en ligne) et intègre :
- Points WTD (infrastructures)
- Services (gendarmerie, bus, taxi, cybercafé…)
- Villes
- Zones de couverture
- Journalisation locale (BOT)
- Heatmap d’usage (preuve d’utilisation)

## Utilisation
1. Ouvrir `index.html` dans un navigateur moderne
2. Connexion Internet requise (Google Maps)
3. Cliquer sur les points et services pour générer des données d’usage
4. Ouvrir `/pages/dashboard-bot.html` pour consulter les statistiques locales

## Données
Les données sont stockées localement dans le navigateur (localStorage).
Aucune donnée personnelle n’est transmise à un serveur.

## Auteur
Patrick Billy — WTD / Élan pour tous
