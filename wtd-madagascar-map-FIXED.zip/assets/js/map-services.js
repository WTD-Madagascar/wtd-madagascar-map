/* ============================================================
   WTD Madagascar — Services utiles
   - Gendarmerie, police
   - Bus, taxi, taxi-moto, tuk-tuk, taxi-phone
   - Cybercafé, hôpital, pharmacie
   - BOT logging compatible
============================================================ */

(function (global) {
  "use strict";

  const SERVICES_PATH = "../assets/data/services-wtd.json";

  let map = null;
  let infoWindow = null;
  let serviceMarkers = [];

  /* =========================
     Utils
  ========================= */
  function parseGps(str) {
    if (!str || !str.includes(",")) return null;
    const [lat, lng] = str.split(",").map(v => Number(v.trim()));
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return { lat, lng };
  }

  function esc(v) {
    return String(v ?? "").replace(/[<>&"]/g, s => ({
      "<": "&lt;",
      ">": "&gt;",
      "&": "&amp;",
      '"': "&quot;"
    }[s]));
  }

  function clearMarkers() {
    serviceMarkers.forEach(m => m.setMap(null));
    serviceMarkers.length = 0;
  }

  /* =========================
     Icônes par type
  ========================= */
  function getServiceIcon(type) {
    const base = "https://maps.google.com/mapfiles/ms/icons/";

    switch (type) {
      case "gendarmerie":
      case "police":
        return base + "red-dot.png";

      case "hopital":
      case "pharmacie":
        return base + "pink-dot.png";

      case "bus":
        return base + "green-dot.png";

      case "taxi":
      case "taxi-moto":
      case "tuk-tuk":
      case "taxi-phone":
        return base + "yellow-dot.png";

      case "cybercafe":
        return base + "blue-dot.png";

      default:
        return base + "purple-dot.png";
    }
  }

  /* =========================
     Chargement des services
  ========================= */
  async function loadServices(mapInstance) {
    map = mapInstance;
    if (!map) {
      console.error("[WTD] map non initialisée");
      return;
    }

    infoWindow = infoWindow || new google.maps.InfoWindow();

    let services;
    try {
      const res = await fetch(SERVICES_PATH, { cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      services = await res.json();
    } catch (e) {
      console.error("[WTD] Impossible de charger services-wtd.json", e);
      return;
    }

    if (!Array.isArray(services)) {
      console.error("[WTD] services-wtd.json invalide (tableau attendu)");
      return;
    }

    clearMarkers();

    services.forEach(s => {
      if (s.visible === false) return;

      const ll = parseGps(s.gps);
      if (!ll) return;

      const marker = new google.maps.Marker({
        position: ll,
        map,
        title: s.nom,
        icon: getServiceIcon(s.type)
      });

      marker.__wtdService = s;

      marker.addListener("click", () => {
        infoWindow.setContent(`
          <div style="max-width:260px">
            <b>${esc(s.nom)}</b><br>
            <b>Type :</b> ${esc(s.type)}<br>
            <b>Zone :</b> ${esc(s.zone || "")}<br>
            <b>Urgence :</b> ${s.urgence ? "Oui" : "Non"}<br>
            <b>GPS :</b> ${esc(s.gps)}
          </div>
        `);
        infoWindow.open(map, marker);

        // 🤖 BOT — TRACE SERVICE
        if (typeof botSaveServiceClick === "function") {
          botSaveServiceClick({
            id: s.id,
            type: s.type,
            gps: s.gps,
            zone: s.zone || null
          });
        }
      });

      serviceMarkers.push(marker);
    });

    console.log("[WTD] Services chargés :", serviceMarkers.length);
  }

  /* =========================
     API publique
  ========================= */
  global.WTD_SERVICES = {
    load: loadServices,
    clear: clearMarkers
  };

})(window);
