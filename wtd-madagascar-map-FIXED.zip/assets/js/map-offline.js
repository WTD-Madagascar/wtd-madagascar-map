botInit({ debug: true });

const map = L.map("map").setView([-18.8792, 47.5079], 13);

L.tileLayer("../assets/tiles/madagascar/{z}/{x}/{y}.png", {
  minZoom: 5,
  maxZoom: 18,
  attribution: "WTD Madagascar (offline)"
}).addTo(map);

fetch("../assets/data/points-wtd.json")
  .then(r => r.json())
  .then(points => {
    points.forEach(p => {
      if (!p.gps || !p.gps.includes(",")) return;

      const [lat, lng] = p.gps.split(",").map(Number);

      const marker = L.marker([lat, lng]).addTo(map);
      marker.bindPopup(`
        <b>${p.nom}</b><br>
        ID : ${p.id}<br>
        Réseau : ${p.reseau}<br>
        Statut : ${p.statut}
      `);

      marker.on("click", () => {
        botSavePointClick(p);
      });
    });
  })
  .catch(err => console.error("Points WTD OFFLINE:", err));
