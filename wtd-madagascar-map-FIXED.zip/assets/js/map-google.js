/* ============================================================
   WTD Madagascar — Carte Google (online) — VERSION INTÉGRALE
   ✔ Points WTD
   ✔ Services (gendarmerie, bus, taxi, tuk-tuk, cybercafé…)
   ✔ Villes
   ✔ Zones (cercles)
   ✔ Fokontany (GeoJSON)
   ✔ BOT + Heatmap
============================================================ */

(function (global) {
  "use strict";

  /* =========================
     CONFIG
  ========================= */

  const IDS = {
    btnCities: "btnCities",
    btnServices: "btnServices",
    btnMapType: "btnMapType",
    btnZoomAll: "btnZoomAll",
    btnZones: "btnZones",
    btnFokontany: "btnFokontany",
    btnHeatmap: "btnHeatmap",
    btnExport: "btnExport"
  };

  const PATHS = {
    points: "../assets/data/points-wtd.json",
    services: "../assets/data/services-wtd.json",
    cities: "../assets/data/villes-madagascar.json",
    fokontany: "../assets/data/fokontany.geojson"
  };

  const DEFAULT_ZONE_RADIUS = 400;

  /* =========================
     ÉTAT GLOBAL
  ========================= */

  let map = null;
  let infoWindow = null;

  let isSatellite = true;

  let pointMarkers = [];
  let serviceMarkers = [];
  let cityMarkers = [];
  let zoneCircles = [];

  let servicesVisible = true;
  let citiesVisible = false;
  let zonesVisible = false;

  let fokontanyLoaded = false;
  let fokontanyVisible = false;

  let heatmap = null;
  let heatmapVisible = false;

  /* =========================
     UTILS
  ========================= */

  function $(id){ return document.getElementById(id); }

  function esc(v){
    return String(v ?? "").replace(/[<>&"]/g, s => ({
      "<":"&lt;", ">":"&gt;", "&":"&amp;", '"':"&quot;"
    }[s]));
  }

  function parseGps(str){
    if (!str || !str.includes(",")) return null;
    const [lat,lng] = str.split(",").map(v => Number(v.trim()));
    return (Number.isFinite(lat) && Number.isFinite(lng)) ? {lat,lng} : null;
  }

  function clearMarkers(list){
    list.forEach(m => m.setMap(null));
    list.length = 0;
  }

  async function fetchJSON(url){
    const r = await fetch(url, { cache:"no-store" });
    if (!r.ok) throw new Error(url + " HTTP " + r.status);
    return r.json();
  }

  function setBtnText(id, txt){
    const el = $(id);
    if (el) el.textContent = txt;
  }

  /* =========================
     ICÔNES SERVICES
  ========================= */

  function getServiceIcon(type){
    const t = String(type||"").toLowerCase();
    const icons = {
      gendarmerie: "https://maps.google.com/mapfiles/ms/icons/red-dot.png",
      police: "https://maps.google.com/mapfiles/ms/icons/red-dot.png",
      bus: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
      taxi: "https://maps.google.com/mapfiles/ms/icons/yellow-dot.png",
      "taxi-moto": "https://maps.google.com/mapfiles/ms/icons/orange-dot.png",
      "tuk-tuk": "https://maps.google.com/mapfiles/ms/icons/green-dot.png",
      tok_tok: "https://maps.google.com/mapfiles/ms/icons/green-dot.png",
      cybercafe: "https://maps.google.com/mapfiles/ms/icons/purple-dot.png"
    };
    return icons[t] || "https://maps.google.com/mapfiles/ms/icons/ltblue-dot.png";
  }

  /* =========================
     POINTS WTD
  ========================= */

  async function loadPointsWTD(){
    const points = await fetchJSON(PATHS.points);
    clearMarkers(pointMarkers);

    for (const p of points){
      const ll = parseGps(p.gps);
      if (!ll) continue;

      const m = new google.maps.Marker({
        position: ll,
        map,
        title: p.nom || p.id || "Point WTD"
      });

      m.__wtdPoint = p;

      m.addListener("click", () => {
        infoWindow.setContent(`
          <b>${esc(p.nom)}</b><br>
          ID : ${esc(p.id)}<br>
          Réseau : ${esc(p.reseau)}<br>
          Statut : ${esc(p.statut)}<br>
          GPS : ${esc(p.gps)}
        `);
        infoWindow.open(map, m);

        if (typeof botSavePointClick === "function") botSavePointClick(p);
        if (heatmapVisible) buildHeatmap();
      });

      pointMarkers.push(m);
    }
  }

  /* =========================
     SERVICES
  ========================= */

  async function loadServices(){
    const services = await fetchJSON(PATHS.services);
    clearMarkers(serviceMarkers);

    for (const s of services){
      const ll = parseGps(s.gps);
      if (!ll) continue;

      const m = new google.maps.Marker({
        position: ll,
        map: servicesVisible ? map : null,
        title: s.nom || s.type || "Service",
        icon: { url: getServiceIcon(s.type) }
      });

      m.__wtdService = s;

      m.addListener("click", () => {
        infoWindow.setContent(`
          <b>${esc(s.nom)}</b><br>
          Type : ${esc(s.type)}<br>
          GPS : ${esc(s.gps)}
        `);
        infoWindow.open(map, m);

        if (typeof botSaveServiceClick === "function")
          botSaveServiceClick(s);
        else if (typeof botSave === "function")
          botSave({ type:"click-service", service:s.type, gps:s.gps });

        if (heatmapVisible) buildHeatmap();
      });

      serviceMarkers.push(m);
    }
  }

  function toggleServices(){
    servicesVisible = !servicesVisible;
    setBtnText(IDS.btnServices, servicesVisible ? "Masquer services" : "Afficher services");
    serviceMarkers.forEach(m => m.setMap(servicesVisible ? map : null));
  }

  /* =========================
     VILLES
  ========================= */

  async function loadCities(){
    const data = await fetchJSON(PATHS.cities);
    const cities = Array.isArray(data.cities) ? data.cities : [];
    clearMarkers(cityMarkers);

    for (const c of cities){
      if (!Number.isFinite(c.lat) || !Number.isFinite(c.lng)) continue;

      const m = new google.maps.Marker({
        position:{lat:c.lat,lng:c.lng},
        map: citiesVisible ? map : null,
        title: c.name
      });

      m.addListener("click", () => {
        infoWindow.setContent(`<b>${esc(c.name)}</b><br>${c.lat}, ${c.lng}`);
        infoWindow.open(map, m);
        if (typeof botSaveCityClick === "function") botSaveCityClick(c);
        if (heatmapVisible) buildHeatmap();
      });

      cityMarkers.push(m);
    }
  }

  function toggleCities(){
    citiesVisible = !citiesVisible;
    setBtnText(IDS.btnCities, citiesVisible ? "Masquer villes" : "Afficher villes");

    if (!cityMarkers.length && citiesVisible){
      loadCities().catch(console.error);
      return;
    }
    cityMarkers.forEach(m => m.setMap(citiesVisible ? map : null));
  }

  /* =========================
     ZONES
  ========================= */

  function buildZones(){
    zoneCircles.forEach(c => c.setMap(null));
    zoneCircles = [];

    for (const m of pointMarkers){
      const p = m.__wtdPoint;
      if (!p) continue;

      const circle = new google.maps.Circle({
        map: zonesVisible ? map : null,
        center: m.getPosition(),
        radius: Number(p.rayon_m) || DEFAULT_ZONE_RADIUS,
        fillOpacity: 0.12,
        strokeOpacity: 0.8
      });
      zoneCircles.push(circle);
    }
  }

  function toggleZones(){
    zonesVisible = !zonesVisible;
    setBtnText(IDS.btnZones, zonesVisible ? "Masquer zones" : "Afficher zones");

    if (!zoneCircles.length && zonesVisible){
      buildZones();
      return;
    }
    zoneCircles.forEach(c => c.setMap(zonesVisible ? map : null));
  }

  /* =========================
     HEATMAP BOT
  ========================= */

  function getBotHeatPoints(){
    if (typeof botRead !== "function") return [];
    const pts = [];

    for (const e of botRead()){
      if (e.gps){
        const ll = parseGps(e.gps);
        if (ll) pts.push(new google.maps.LatLng(ll.lat,ll.lng));
      }
      if (Number.isFinite(e.lat) && Number.isFinite(e.lng)){
        pts.push(new google.maps.LatLng(e.lat,e.lng));
      }
    }
    return pts;
  }

  function buildHeatmap(){
    const data = getBotHeatPoints();
    if (!data.length) return;

    if (!google.maps.visualization){
      console.warn("Heatmap: libraries=visualization manquant");
      return;
    }

    if (!heatmap){
      heatmap = new google.maps.visualization.HeatmapLayer({
        data,
        radius:30,
        opacity:0.7
      });
    } else {
      heatmap.setData(data);
    }
  }

  function toggleHeatmap(){
    heatmapVisible = !heatmapVisible;
    setBtnText(IDS.btnHeatmap, heatmapVisible ? "Masquer heatmap" : "Heatmap");

    if (!heatmapVisible){
      if (heatmap) heatmap.setMap(null);
      return;
    }

    buildHeatmap();
    if (heatmap) heatmap.setMap(map);
  }

  /* =========================
     INIT MAP
  ========================= */

  async function initMap(){
    if (typeof botInit === "function") botInit({ debug:true });

    map = new google.maps.Map($("map"), {
      zoom:6,
      center:{lat:-18.8792,lng:47.5079},
      mapTypeId:"satellite",
      gestureHandling:"greedy"
    });

    infoWindow = new google.maps.InfoWindow();

    map.addListener("click", e => {
      if (typeof botSaveMapClick === "function")
        botSaveMapClick(e.latLng.lat(), e.latLng.lng());
      if (heatmapVisible) buildHeatmap();
    });

    await loadPointsWTD();
    await loadServices();
    bindUI();
  }

  /* =========================
     UI
  ========================= */

  function bindUI(){
    const mapType = $(IDS.btnMapType);
    if (mapType) mapType.onclick = () => {
      isSatellite = !isSatellite;
      map.setMapTypeId(isSatellite ? "satellite" : "roadmap");
      setBtnText(IDS.btnMapType, isSatellite ? "Mode Plan" : "Mode Satellite");
    };

    const zoom = $(IDS.btnZoomAll);
    if (zoom) zoom.onclick = () => {
      const b = new google.maps.LatLngBounds();
      [...pointMarkers,...serviceMarkers,...cityMarkers].forEach(m=>{
        if (m.getMap()) b.extend(m.getPosition());
      });
      map.fitBounds(b);
    };

    const s = $(IDS.btnServices); if (s) s.onclick = toggleServices;
    const c = $(IDS.btnCities); if (c) c.onclick = toggleCities;
    const z = $(IDS.btnZones); if (z) z.onclick = toggleZones;
    const h = $(IDS.btnHeatmap); if (h) h.onclick = toggleHeatmap;
    const e = $(IDS.btnExport); if (e) e.onclick = () => botExportJSON?.();
  }

  /* =========================
     EXPORT
  ========================= */

  global.initMap = initMap;

})(window);
