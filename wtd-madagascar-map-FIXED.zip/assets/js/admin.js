/* ============================================================
   WTD Sync — Import & merge d'un export BOT
   Vérifie signature simple (anti-altération basique)
============================================================ */

(function (global) {
  "use strict";

  function simpleHash(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = ((h << 5) - h) + str.charCodeAt(i);
      h |= 0;
    }
    return h.toString(16);
  }

  function syncImportFile(file, msgEl) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        const { meta, events, signature } = data;

        if (!meta || !Array.isArray(events) || !signature) {
          throw new Error("Fichier invalide (meta/events/signature manquants)");
        }

        const check = simpleHash(JSON.stringify({ meta, events }));
        if (check !== signature) {
          throw new Error("Signature invalide (fichier modifié)");
        }

        if (typeof botImportJSON === "function") {
          botImportJSON(data, { merge: true });
        } else {
          // fallback merge minimal
          const existing = (typeof botRead === "function") ? botRead() : [];
          localStorage.setItem("wtd_bot_events_v1", JSON.stringify(existing.concat(events)));
          localStorage.setItem("wtd_bot_meta_v1", JSON.stringify(meta));
        }

        if (msgEl) msgEl.innerHTML = `<p style="color:green;font-weight:700">✔ Import OK (${events.length} événements)</p>`;
      } catch (err) {
        if (msgEl) msgEl.innerHTML = `<p style="color:red;font-weight:700">❌ ${err.message}</p>`;
        console.error(err);
      }
    };
    reader.readAsText(file);
  }

  global.WTD_SYNC = { syncImportFile };

})(window);
