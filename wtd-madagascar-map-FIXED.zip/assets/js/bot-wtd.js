/* ============================================================
   WTD BOT — Collecte & journalisation d’actions (offline-first)
   Auteur : Patrick Billy / WTD
   Stockage : localStorage
   Compatible : <script> classique + ES Module (optionnel)
============================================================ */

(function (global) {
  "use strict";

  const BOT_KEY = "wtd_bot_events_v1";
  const BOT_META_KEY = "wtd_bot_meta_v1";

  let enabled = false;
  let sessionId = null;
  let options = { debug: false };

  /* =========================
     Utils
  ========================= */
  function nowISO() {
    return new Date().toISOString();
  }

  function uid() {
    return "wtd-" + Math.random().toString(36).slice(2) + "-" + Date.now();
  }

  function safeJSONParse(v, def) {
    try { return JSON.parse(v); } catch { return def; }
  }

  function loadStore(key, def) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? safeJSONParse(raw, def) : def;
    } catch {
      return def;
    }
  }

  function saveStore(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Signature simple (anti-altération basique)
  function simpleHash(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = ((h << 5) - h) + str.charCodeAt(i);
      h |= 0;
    }
    return h.toString(16);
  }

  /* =========================
     Init
  ========================= */
  function botInit(opts = {}) {
    if (enabled) return;

    enabled = true;
    options = { debug: false, ...opts };
    sessionId = uid();

    const meta = {
      sessionId,
      startedAt: nowISO(),
      userAgent: (typeof navigator !== "undefined" ? navigator.userAgent : ""),
      lang: (typeof navigator !== "undefined" ? navigator.language : ""),
      options
    };

    saveStore(BOT_META_KEY, meta);

    botSave({
      type: "bot-init",
      message: "Bot WTD initialisé",
      options: { ...options }
    });

    if (options.debug) console.info("[WTD BOT] init", meta);
  }

  function botIsEnabled() {
    return enabled;
  }

  /* =========================
     Save / Read
  ========================= */
  function botSave(event = {}) {
    if (!enabled) return;

    const events = loadStore(BOT_KEY, []);
    const payload = {
      id: uid(),
      sessionId,
      at: nowISO(),
      ...event
    };

    events.push(payload);
    saveStore(BOT_KEY, events);

    if (options.debug || event.debug) {
      console.debug("[WTD BOT] event", payload);
    }
  }

  function botRead() {
    return loadStore(BOT_KEY, []);
  }

  function botLast(n = 10) {
    const events = loadStore(BOT_KEY, []);
    return events.slice(-n);
  }

  function botMeta() {
    return loadStore(BOT_META_KEY, {});
  }

  function botClear(confirm = false) {
    if (!confirm) return false;
    localStorage.removeItem(BOT_KEY);
    localStorage.removeItem(BOT_META_KEY);
    enabled = false;
    sessionId = null;
    return true;
  }

  /* =========================
     Export / Import
  ========================= */
  function botExportObject() {
    const meta = loadStore(BOT_META_KEY, {});
    const events = loadStore(BOT_KEY, []);
    const payloadCore = { meta, events };
    const signature = simpleHash(JSON.stringify(payloadCore));
    return { ...payloadCore, signature };
  }

  function botExportJSON(filename = "wtd-bot-export.json") {
    const payload = botExportObject();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    if (options.debug) console.info("[WTD BOT] export", filename);
  }

  // Import + merge (avec vérif signature)
  function botImportJSON(data, { merge = true } = {}) {
    const obj = (typeof data === "string") ? JSON.parse(data) : data;
    if (!obj || !obj.meta || !Array.isArray(obj.events) || !obj.signature) {
      throw new Error("Fichier BOT invalide");
    }

    const check = simpleHash(JSON.stringify({ meta: obj.meta, events: obj.events }));
    if (check !== obj.signature) {
      throw new Error("Signature invalide (fichier modifié)");
    }

    if (merge) {
      const existing = botRead();
      const merged = existing.concat(obj.events);
      saveStore(BOT_KEY, merged);
    } else {
      saveStore(BOT_KEY, obj.events);
    }
    saveStore(BOT_META_KEY, obj.meta);

    return { imported: obj.events.length, merge };
  }

  /* =========================
     Helpers WTD
  ========================= */
  function botSaveMapClick(lat, lng) {
    botSave({ type: "map-click", lat, lng });
  }

  function botSavePointClick(point = {}) {
    botSave({
      type: "click-point",
      id: point.id || null,
      nom: point.nom || null,
      gps: point.gps || null,
      reseau: point.reseau || null,
      statut: point.statut || null
    });
  }

  function botSaveCityClick(city = {}) {
    botSave({
      type: "click-city",
      name: city.name || null,
      lat: Number.isFinite(city.lat) ? city.lat : null,
      lng: Number.isFinite(city.lng) ? city.lng : null
    });
  }

  function botSaveFokontanyClick(props = {}) {
    botSave({
      type: "click-fokontany",
      id: props.id || null,
      nom: props.nom || null
    });
  }

  function botConsole() {
    try { console.table(botRead()); } catch { console.log(botRead()); }
  }

  /* =========================
     Expose (global)
  ========================= */
  const api = {
    botInit,
    botIsEnabled,
    botSave,
    botRead,
    botLast,
    botMeta,
    botClear,

    botExportObject,
    botExportJSON,
    botImportJSON,

    botSaveMapClick,
    botSavePointClick,
    botSaveCityClick,
    botSaveFokontanyClick,

    botConsole
  };

  global.BOT_WTD = api;

  // raccourcis globaux (plus simple dans tes pages)
  global.botInit = botInit;
  global.botSave = botSave;
  global.botRead = botRead;
  global.botLast = botLast;
  global.botMeta = botMeta;
  global.botClear = botClear;
  global.botExportJSON = botExportJSON;
  global.botImportJSON = botImportJSON;

  global.botSaveMapClick = botSaveMapClick;
  global.botSavePointClick = botSavePointClick;
  global.botSaveCityClick = botSaveCityClick;
  global.botSaveFokontanyClick = botSaveFokontanyClick;

  global.botConsole = botConsole;

})(typeof window !== "undefined" ? window : globalThis);

async function getOrCreateKeyPair(){
  const stored = localStorage.getItem("wtd_sign_key");
  if (stored){
    const jwk = JSON.parse(stored);
    return crypto.subtle.importKey(
      "jwk",
      jwk,
      { name: "ECDSA", namedCurve: "P-256" },
      true,
      ["sign"]
    );
  }

  const keyPair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"]
  );

  const jwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
  localStorage.setItem("wtd_sign_key", JSON.stringify(jwk));

  return keyPair.privateKey;
}

function botSaveServiceClick(service){
  botSave({
    type: "click-service",
    serviceType: service.type,
    id: service.id,
    nom: service.nom,
    gps: service.gps
  });
}
