/* ============================================================
   WTD Crypto — Clés + Signature + Vérification (offline)
   Algo: ECDSA P-256 + SHA-256 (WebCrypto)
============================================================ */

const WTD_CRYPTO = (() => {
  const PRIV_KEY_STORE = "wtd_sign_priv_jwk_v1";
  const PUB_KEY_STORE  = "wtd_sign_pub_jwk_v1";

  const enc = new TextEncoder();

  function b64FromBytes(bytes){
    let bin = "";
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin);
  }

  function bytesFromB64(b64){
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  async function sha256HexOfString(str){
    const data = enc.encode(str);
    const hashBuf = await crypto.subtle.digest("SHA-256", data);
    const hashArr = Array.from(new Uint8Array(hashBuf));
    return hashArr.map(b => b.toString(16).padStart(2,"0")).join("");
  }

  async function generateAndStoreKeyPair(){
    const keyPair = await crypto.subtle.generateKey(
      { name: "ECDSA", namedCurve: "P-256" },
      true,
      ["sign", "verify"]
    );

    const privJwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
    const pubJwk  = await crypto.subtle.exportKey("jwk", keyPair.publicKey);

    localStorage.setItem(PRIV_KEY_STORE, JSON.stringify(privJwk));
    localStorage.setItem(PUB_KEY_STORE, JSON.stringify(pubJwk));

    return { privJwk, pubJwk };
  }

  async function getOrCreateKeys(){
    const privRaw = localStorage.getItem(PRIV_KEY_STORE);
    const pubRaw  = localStorage.getItem(PUB_KEY_STORE);

    if (privRaw && pubRaw){
      return { privJwk: JSON.parse(privRaw), pubJwk: JSON.parse(pubRaw) };
    }
    return generateAndStoreKeyPair();
  }

  async function importPrivateKey(privJwk){
    return crypto.subtle.importKey(
      "jwk",
      privJwk,
      { name: "ECDSA", namedCurve: "P-256" },
      true,
      ["sign"]
    );
  }

  async function importPublicKey(pubJwk){
    return crypto.subtle.importKey(
      "jwk",
      pubJwk,
      { name: "ECDSA", namedCurve: "P-256" },
      true,
      ["verify"]
    );
  }

  // Sign payload (JSON object) -> { hash, signatureB64, algo }
  async function signPayload(payloadObj){
    const { privJwk } = await getOrCreateKeys();
    const privateKey = await importPrivateKey(privJwk);

    // On signe le SHA256 du JSON "canonique" (stringify stable simple)
    const payloadStr = JSON.stringify(payloadObj);
    const payloadHashBuf = await crypto.subtle.digest("SHA-256", enc.encode(payloadStr));

    const sigBuf = await crypto.subtle.sign(
      { name: "ECDSA", hash: "SHA-256" },
      privateKey,
      payloadHashBuf
    );

    const signatureB64 = b64FromBytes(new Uint8Array(sigBuf));
    const hashHex = Array.from(new Uint8Array(payloadHashBuf))
      .map(b => b.toString(16).padStart(2,"0"))
      .join("");

    return {
      hash: hashHex,
      signature: signatureB64,
      algo: "ECDSA-P256-SHA256"
    };
  }

  // Verify payload + proof with a given public JWK
  async function verifySignature({ payloadObj, proof, pubJwk }){
    if (!proof?.hash || !proof?.signature) return { ok:false, reason:"Proof incomplete" };

    const publicKey = await importPublicKey(pubJwk);

    const payloadStr = JSON.stringify(payloadObj);
    const payloadHashBuf = await crypto.subtle.digest("SHA-256", enc.encode(payloadStr));

    const hashHex = Array.from(new Uint8Array(payloadHashBuf))
      .map(b => b.toString(16).padStart(2,"0"))
      .join("");

    if (hashHex !== proof.hash){
      return { ok:false, reason:"Hash mismatch", hash: hashHex };
    }

    const sigBytes = bytesFromB64(proof.signature);

    const ok = await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      publicKey,
      sigBytes,
      payloadHashBuf
    );

    return ok ? { ok:true, reason:"Valid" } : { ok:false, reason:"Bad signature" };
  }

  // Export public key JWK (for sharing)
  function getPublicKeyJwk(){
    const pubRaw = localStorage.getItem(PUB_KEY_STORE);
    return pubRaw ? JSON.parse(pubRaw) : null;
  }

  function downloadJSON(filename, obj){
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type:"application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportPublicKeyFile(){
    const pubJwk = getPublicKeyJwk();
    if (!pubJwk) throw new Error("Public key not found (init/sign first).");
    downloadJSON("wtd-public-key.json", pubJwk);
  }

  return {
    getOrCreateKeys,
    signPayload,
    verifySignature,
    exportPublicKeyFile,
    getPublicKeyJwk
  };
})();
