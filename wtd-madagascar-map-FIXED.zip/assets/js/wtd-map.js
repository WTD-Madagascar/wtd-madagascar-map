function getBotHeatPoints() {
  const events = botRead();
  const pts = [];

  for (const e of events) {
    if (e.type === "click-point" && e.gps) {
      const [lat, lng] = e.gps.split(",").map(Number);
      if (Number.isFinite(lat) && Number.isFinite(lng)) {
        pts.push(new google.maps.LatLng(lat, lng));
      }
    }

    if (e.type === "click-city") {
      pts.push(new google.maps.LatLng(e.lat, e.lng));
    }

    if (e.type === "map-click") {
      pts.push(new google.maps.LatLng(e.lat, e.lng));
    }
  }
  return pts;
}
